package sample;

public class Protectedp2 {
public static void main(String[]args) {
	protectedp1 obj4 =newprotectedp1();
	obj4.display();
}
}

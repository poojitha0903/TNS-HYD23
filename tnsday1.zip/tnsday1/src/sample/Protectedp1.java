package sample;

public class Protectedp1 {
	protected void display()
	{
		System.out.println("protected access modifier");
	}
}

package sample;

public class User {
int a=10;
static int b=20;
int display() 
{
	return 20;
}
static void display1()
{
	System.out.println(20);
}
public static void main(String[]args) {
	//TODOAuto generated method stub
User a=new User();
System.out.println(a.a);
System.out.println(a.b);
User.display1();
}
}

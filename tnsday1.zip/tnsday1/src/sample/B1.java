package sample;

public class B1 {
int a=10;
static int b=20;
int display()
{
return 10;
}
static void display1()
{
	System.out.println(20);
}
public class B2
{
	public static void main(String[]args) {
	int c=30;
	//TODO Auto-generated method stub
	B1 b=new B1();
	System.out.println(c);
	System.out.println(b.a);
	System.out.println(B1.b);
	b.display();
	B1.display1();
	}
}
}

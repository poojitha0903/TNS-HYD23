package sample;

public class B {
	int a=10;
	static int b=20;
	private static A a1;
	
	public static void main(String[]args) {
		//TODO Auto-genrted method stub
		int c=30;
B a1= new B();
System.out.println(a1.b);
System.out.println(B.b);

		
	}

}

package sample;

public class D {
private void display() {
	System.out.println("private");
}
public static void main(String[]args) {
	//TODO Auto-generated method stub
	D d1 = new D ();
	d1.display();
	
}
}

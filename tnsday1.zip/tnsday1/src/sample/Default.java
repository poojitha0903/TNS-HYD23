package sample;

public class Default {
	void display()
	{
		System.out.println("TNS");
	}
public static void main(String[]args) {
Default d1 = new Default();
d1.display();
}

}

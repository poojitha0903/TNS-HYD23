package student;

public class Main3 {
	public static void main(String[] args) {
		Student3getterssetterAddfunctinality student = new student3getterssetterAddfunctinality ();
		student.setAge (10);
		student.setName("poojitha");
		student.setAddress ("correct");
		//calling the function
		System.out.println (s3.run ());
	}

}


package student;

public class Student1 {
private String name;
private String address;
private int id;
public int age;
}

package student;

public class Main2 {
	
	public class Main2getterssetters {
		
		public static void main(String[] args) {
			Studentgetterssetters s2= new Studentgetterssetters();
			s2.setAge(20);
			System.out.println(s2.getAge());
			s2.setName("Poojitha");
			System.out.println(s2.getName());
		}
	}
	
	
			
		
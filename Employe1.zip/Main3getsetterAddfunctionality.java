package Employe;

public class Main3getsetterAddfunctionality {
	public static void main(String[] args) {
		Employe3getsetterAddfunctionality  employe = new Employe3getsetterAddfunctionality ();
		employe.setSalary (4000);
		employe.setName ("poojitha");
		employe.setAddress ("Correct");
		//calling the function
		System.out.println (Employe.run ());
	}

}

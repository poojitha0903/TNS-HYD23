package Employe;

public class Main2 {
	public static void main(String[] args) {
		Employe2getsetters e2= new Employe2getsetters();
		e2.setSalary(4000);
		System.out.println(e2.getSalary());
		
		
		e2.setName("Poojitha");
		System.out.println(e2.getName());
		
}
}
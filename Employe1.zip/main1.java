package Employe;

public class main1 {
	public static void main(String[] args) {
		Employe1 e1= new Employe1();
		e1.salary=4000;
		System.out.println(e1.salary);
	}
}

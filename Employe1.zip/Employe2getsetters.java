package Employe;

public class Employe2getsetters {
	private String name;
	private String address;
	private int salary;
	public int getSalary() {
	return salary;	
}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
}
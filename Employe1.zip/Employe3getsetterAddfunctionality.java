package Employe;

public class Employe3getsetterAddfunctionality {
	private String name;
	private String address;
	private int salary;
}

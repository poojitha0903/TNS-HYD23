package Employe;

public class Employe1 {
	private String name;
	private String address;
	public int salary ;
	
}

